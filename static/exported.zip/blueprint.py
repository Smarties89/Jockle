#!/bin/python
# coding: utf-8
# Standard libraries
import logging

# Third party libraries
from flask import Blueprint

log = logging.getLogger()
app = Blueprint("blueprint", __name__)


@app.route("/ham", methods=["GET"])
def ham():
    return "Welcome to the world", 200

@app.route("/reax", methods=["GET"])
def reax():
    return "ham", 200
