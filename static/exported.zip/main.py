#!/bin/python
# coding: utf-8
# Standard libraries
import logging

# Third party libraries
from flask import Flask

# Project specific libraries
import blueprint

log = logging.getLogger()
app = Flask(__name__)

# TODO: Overwrite.
def debug():
    return True

if debug():
    logging.basicConfig()
    log.setLevel(logging.DEBUG)
else:
    logging.basicConfig(filename="mylogs.txt")

app.register_blueprint(blueprint.app)


def main():
    app.debug = debug()
    if debug():
        log.info("Starting app in DEBUG mode")
        app.run(host="127.0.0.1", port=5000)
    else:
        log.info("Starting app in PRODUCTION mode")
        app.run(host="0.0.0.0", port=5000)

if __name__ == "__main__":
    main()